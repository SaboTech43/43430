
// Function to dynamically update the form using the HTML DOM
function updateForm() {
    // Get the table element by its class name
    var table = document.querySelector('.table');

    // Create a new row element
    var newRow = document.createElement('tr');
    newRow.className = 'row';

    // Create new cell elements for the row
    var locationCell = document.createElement('td');
    locationCell.textContent = 'New Location';

    var destinationCell = document.createElement('td');
    destinationCell.textContent = 'New Destination';

    var departureTimeCell = document.createElement('td');
    departureTimeCell.textContent = 'New Departure Time';

    var seatsCell = document.createElement('td');
    seatsCell.textContent = 'New Seats';

    var buttonCell = document.createElement('td');
    var button = document.createElement('button');
    button.className = 'ride-success';
    button.textContent = 'New Ride Details';
    buttonCell.appendChild(button);

    // Append the cells to the new row
    newRow.appendChild(locationCell);
    newRow.appendChild(destinationCell);
    newRow.appendChild(departureTimeCell);
    newRow.appendChild(seatsCell);
    newRow.appendChild(buttonCell);

    // Append the new row to the table
    table.appendChild(newRow);
}

// Call the updateForm function to dynamically update the form
updateForm();